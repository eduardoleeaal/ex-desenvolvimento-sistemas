# Exercício realizado em sala
### No dia 04/04/25
